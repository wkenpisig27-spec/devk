<?php
/**
 * PKO Website - Game Rules
 */

require_once __DIR__ . '/includes/config.php';

Security::setHeaders();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= metaTags('Game Rules', 'Read the Game Rules for ' . SERVER_NAME) ?>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <link rel="icon" type="image/png" href="<?= asset('images/favicon.png') ?>">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar scrolled" role="navigation">
        <div class="container">
            <div class="navbar-content">
                <a href="/" class="navbar-logo"><?= e(SERVER_NAME) ?></a>
                
                <ul class="navbar-menu" id="navbar-menu">
                    <li><a href="/" class="navbar-link">Home</a></li>
                    <li><a href="/leaderboard.php" class="navbar-link">Leaderboard</a></li>
                    <li><a href="/download.php" class="navbar-link">Download</a></li>
                    <li><a href="https://discord.com/invite/NHmFsuMpS5" target="_blank" class="navbar-link">Discord</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <?php if (Auth::check()): ?>
                        <a href="/dashboard.php" class="btn btn-ghost">Dashboard</a>
                        <a href="#" class="btn btn-primary" data-logout>Logout</a>
                    <?php else: ?>
                        <a href="/login.php" class="btn btn-ghost">Login</a>
                        <a href="/register.php" class="btn btn-primary">Play Free</a>
                    <?php endif; ?>
                </div>
                
                <button class="navbar-toggle" aria-label="Toggle menu" aria-expanded="false">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
    </nav>

    <div style="padding-top: 100px;"></div>

    <section class="section">
        <div class="container" style="max-width: 800px;">
            <h1 class="title-section mb-6">Game Rules</h1>
            <p class="text-muted mb-8">Last updated: <?= date('F j, Y') ?></p>
            
            <div class="card p-8 mb-6">
                <div class="legal-content">
                    <p class="text-gold font-semibold mb-4">⚠️ Violation of these rules may result in warnings, temporary bans, or permanent account termination.</p>
                    
                    <h2>🚫 Cheating & Exploits</h2>
                    <ul>
                        <li><strong>No Hacking:</strong> Using hacks, cheats, trainers, or modified clients is strictly prohibited</li>
                        <li><strong>No Botting:</strong> Automated gameplay using bots or macros is not allowed</li>
                        <li><strong>No Speed Hacks:</strong> Any modification to movement speed or attack speed</li>
                        <li><strong>No Bug Exploitation:</strong> Report bugs instead of exploiting them for personal gain</li>
                        <li><strong>No Packet Manipulation:</strong> Modifying network packets to gain advantages</li>
                    </ul>
                    <p class="text-muted text-sm mt-2">Penalty: Permanent ban on first offense</p>
                    
                    <h2>💰 Economy Rules</h2>
                    <ul>
                        <li><strong>No Real Money Trading (RMT):</strong> Selling or buying in-game items/currency for real money is forbidden</li>
                        <li><strong>No Account Trading:</strong> Buying, selling, or sharing accounts is not allowed</li>
                        <li><strong>No Scamming:</strong> Deceiving other players in trades or transactions</li>
                        <li><strong>No Item Duplication:</strong> Exploiting bugs to duplicate items or currency</li>
                    </ul>
                    <p class="text-muted text-sm mt-2">Penalty: Permanent ban + removal of all items/currency</p>
                    
                    <h2>💬 Chat & Communication</h2>
                    <ul>
                        <li><strong>Be Respectful:</strong> Treat all players with respect and courtesy</li>
                        <li><strong>No Hate Speech:</strong> Racism, sexism, homophobia, or discrimination is not tolerated</li>
                        <li><strong>No Harassment:</strong> Bullying, stalking, or threatening other players</li>
                        <li><strong>No Spam:</strong> Flooding chat with repeated messages or advertisements</li>
                        <li><strong>No Advertising:</strong> Promoting other servers or external services</li>
                        <li><strong>No Impersonation:</strong> Pretending to be staff members or other players</li>
                        <li><strong>English in World Chat:</strong> Please use English in public channels</li>
                    </ul>
                    <p class="text-muted text-sm mt-2">Penalty: Mute → Temporary ban → Permanent ban</p>
                    
                    <h2>⚔️ PvP & Gameplay</h2>
                    <ul>
                        <li><strong>No Kill Stealing:</strong> Intentionally stealing kills from other players farming</li>
                        <li><strong>No Spawn Camping:</strong> Repeatedly killing players at spawn points</li>
                        <li><strong>No Training:</strong> Leading monsters to other players to kill them</li>
                        <li><strong>Fair Play:</strong> Play fairly and don't use exploits for advantages in PvP</li>
                    </ul>
                    <p class="text-muted text-sm mt-2">Penalty: Warning → Temporary ban</p>
                    
                    <h2>👤 Account Rules</h2>
                    <ul>
                        <li><strong>One Account Per Person:</strong> Multi-accounting to bypass restrictions is not allowed</li>
                        <li><strong>Account Security:</strong> You are responsible for your account's security</li>
                        <li><strong>Appropriate Names:</strong> Character and guild names must not be offensive</li>
                        <li><strong>No Account Sharing:</strong> Don't share your account credentials</li>
                    </ul>
                    <p class="text-muted text-sm mt-2">Penalty: Account deletion or name change</p>
                    
                    <h2>🛡️ Staff Rules</h2>
                    <ul>
                        <li>Staff decisions are final and should be respected</li>
                        <li>Do not argue with staff in public channels - use tickets</li>
                        <li>False reports may result in penalties</li>
                        <li>Staff will never ask for your password</li>
                    </ul>
                </div>
            </div>
            
            <div class="card p-6 text-center">
                <h3 class="font-semibold mb-2">Need to Report a Violation?</h3>
                <p class="text-muted mb-4">Contact our staff team through Discord with evidence (screenshots/videos)</p>
                <a href="https://discord.com/invite/NHmFsuMpS5" target="_blank" class="btn btn-primary">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24" style="margin-right: 8px;"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>
                    Join Discord
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="/" class="footer-logo"><?= e(SERVER_NAME) ?></a>
                    <p class="footer-description">
                        Embark on the ultimate pirate MMORPG adventure. Sail the seas, battle enemies, and become a legend!
                    </p>
                    <div class="footer-social">
                        <a href="https://discord.com/invite/NHmFsuMpS5" target="_blank" aria-label="Discord">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>
                        </a>
                        <a href="#" aria-label="Facebook">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        </a>
                        <a href="#" aria-label="YouTube">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4 class="footer-title">Game</h4>
                    <ul class="footer-links">
                        <li><a href="/download.php">Download</a></li>
                        <li><a href="/register.php">Register</a></li>
                        <li><a href="/leaderboard.php">Leaderboard</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="footer-title">Community</h4>
                    <ul class="footer-links">
                        <li><a href="https://discord.com/invite/NHmFsuMpS5" target="_blank">Discord</a></li>
                        <li><a href="https://discord.com/invite/NHmFsuMpS5" target="_blank">Support</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="footer-title">Legal</h4>
                    <ul class="footer-links">
                        <li><a href="/terms.php">Terms of Service</a></li>
                        <li><a href="/privacy.php">Privacy Policy</a></li>
                        <li><a href="/rules.php">Game Rules</a></li>
                        <li><a href="/refund.php">Refund Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= e(SERVER_NAME) ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="<?= asset('js/main.js') ?>"></script>
</body>
</html>
