<?php
/**
 * PKO Website Helper Functions
 * 
 * Utility functions for views, formatting, and common operations
 */

declare(strict_types=1);

/**
 * JSON response helper for API endpoints
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Error JSON response
 */
function jsonError(string $message, int $statusCode = 400): void
{
    jsonResponse(['success' => false, 'error' => $message], $statusCode);
}

/**
 * Success JSON response
 */
function jsonSuccess(array $data = [], string $message = 'Success'): void
{
    jsonResponse(array_merge(['success' => true, 'message' => $message], $data));
}

/**
 * Redirect helper
 */
function redirect(string $url, int $statusCode = 302): void
{
    header("Location: $url", true, $statusCode);
    exit;
}

/**
 * Flash message helper
 */
function flash(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['flash'][$type][] = $message;
}

/**
 * Get and clear flash messages
 */
function getFlash(): array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flash;
}

/**
 * Check for flash messages
 */
function hasFlash(): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    return !empty($_SESSION['flash']);
}

/**
 * Format number with abbreviation (K, M, B)
 */
function formatNumber(int $number): string
{
    if ($number >= 1000000000) {
        return round($number / 1000000000, 1) . 'B';
    } elseif ($number >= 1000000) {
        return round($number / 1000000, 1) . 'M';
    } elseif ($number >= 1000) {
        return round($number / 1000, 1) . 'K';
    }
    return (string)$number;
}

/**
 * Format experience to percentage for next level
 */
function formatExpProgress(int $exp, int $level): array
{
    // PKO level exp formula (simplified)
    $expTable = getExpTable();
    $currentLevelExp = $expTable[$level] ?? 0;
    $nextLevelExp = $expTable[$level + 1] ?? $expTable[100] ?? PHP_INT_MAX;
    
    $progress = $nextLevelExp > $currentLevelExp
        ? (($exp - $currentLevelExp) / ($nextLevelExp - $currentLevelExp)) * 100
        : 100;
    
    return [
        'current' => $exp,
        'required' => $nextLevelExp,
        'percentage' => min(100, max(0, $progress))
    ];
}

/**
 * Get experience table (simplified PKO exp curve)
 */
function getExpTable(): array
{
    static $table = null;
    if ($table === null) {
        $table = [0 => 0];
        for ($i = 1; $i <= 100; $i++) {
            // Exponential growth formula
            $table[$i] = (int)($table[$i - 1] + pow($i, 2.5) * 50);
        }
    }
    return $table;
}

/**
 * Format time ago
 */
function timeAgo(string $datetime): string
{
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return "$mins minute" . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return "$hours hour" . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        return "$days day" . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('M j, Y', $timestamp);
    }
}

/**
 * Format duration (seconds to human readable)
 */
function formatDuration(int $seconds): string
{
    if ($seconds < 60) {
        return "$seconds second" . ($seconds !== 1 ? 's' : '');
    }
    
    $parts = [];
    
    $days = floor($seconds / 86400);
    if ($days > 0) {
        $parts[] = "$days day" . ($days > 1 ? 's' : '');
        $seconds %= 86400;
    }
    
    $hours = floor($seconds / 3600);
    if ($hours > 0) {
        $parts[] = "$hours hour" . ($hours > 1 ? 's' : '');
        $seconds %= 3600;
    }
    
    $minutes = floor($seconds / 60);
    if ($minutes > 0) {
        $parts[] = "$minutes minute" . ($minutes > 1 ? 's' : '');
    }
    
    return implode(', ', $parts);
}

/**
 * Get character class name from job string
 */
function getClassName(string $job): string
{
    $classes = [
        'newbie' => 'Newbie',
        'swordsman' => 'Swordsman',
        'hunter' => 'Hunter',
        'sailor' => 'Sailor',
        'explorer' => 'Explorer',
        'herbalist' => 'Herbalist',
        'champion' => 'Champion',
        'crusader' => 'Crusader',
        'sharpshooter' => 'Sharpshooter',
        'cleric' => 'Cleric',
        'seal_master' => 'Seal Master',
        'voyager' => 'Voyager',
    ];
    
    $jobLower = strtolower(trim($job));
    return $classes[$jobLower] ?? ucfirst($job);
}

/**
 * Get class icon path - returns SVG for styling flexibility
 */
function getClassIcon(string $job): string
{
    $job = strtolower(trim(str_replace(' ', '_', $job)));
    
    // Valid class names
    $validClasses = [
        'newbie', 'swordsman', 'hunter', 'sailor', 'explorer', 
        'herbalist', 'champion', 'crusader', 'sharpshooter', 
        'cleric', 'seal_master', 'voyager'
    ];
    
    // Fallback to newbie if unknown class
    if (!in_array($job, $validClasses)) {
        $job = 'newbie';
    }
    
    return "/assets/images/classes/{$job}.svg";
}

/**
 * Check if game server is online
 */
function isServerOnline(): bool
{
    static $status = null;
    
    if ($status !== null) {
        return $status;
    }
    
    $socket = @fsockopen(GATE_SERVER_IP, GATE_SERVER_PORT, $errno, $errstr, 2);
    
    if ($socket) {
        fclose($socket);
        $status = true;
    } else {
        $status = false;
    }
    
    return $status;
}

/**
 * Get server statistics
 */
function getServerStats(): array
{
    static $stats = null;
    
    if ($stats !== null) {
        return $stats;
    }
    
    try {
        $stats = [
            'online' => isServerOnline(),
            'players_online' => AccountModel::getOnlineCount(),
            'total_accounts' => AccountModel::getTotalAccounts(),
            'total_characters' => CharacterModel::getTotalCharacters(),
            'total_guilds' => GuildModel::getTotalGuilds(),
        ];
    } catch (Exception $e) {
        error_log("Failed to get server stats: " . $e->getMessage());
        $stats = [
            'online' => false,
            'players_online' => 0,
            'total_accounts' => 0,
            'total_characters' => 0,
            'total_guilds' => 0,
        ];
    }
    
    return $stats;
}

/**
 * Asset URL helper with cache busting
 */
function asset(string $path): string
{
    $fullPath = ROOT_PATH . '/assets/' . ltrim($path, '/');
    $version = file_exists($fullPath) ? filemtime($fullPath) : time();
    return '/assets/' . ltrim($path, '/') . '?v=' . $version;
}

/**
 * Include a template partial
 */
function partial(string $name, array $data = []): void
{
    extract($data);
    include PAGES_PATH . "/partials/{$name}.php";
}

/**
 * Safe output (escaped HTML)
 */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * Get current page name
 */
function getCurrentPage(): string
{
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH);
    $page = basename($path, '.php');
    return $page === '' || $page === 'index' ? 'home' : $page;
}

/**
 * Check if current page matches
 */
function isPage(string $page): bool
{
    return getCurrentPage() === $page;
}

/**
 * Generate pagination HTML
 */
function pagination(int $current, int $total, int $perPage, string $baseUrl): string
{
    $totalPages = ceil($total / $perPage);
    if ($totalPages <= 1) return '';
    
    $html = '<nav class="pagination"><ul>';
    
    // Previous
    if ($current > 1) {
        $html .= '<li><a href="' . e($baseUrl . '?page=' . ($current - 1)) . '">&laquo;</a></li>';
    }
    
    // Page numbers
    $start = max(1, $current - 2);
    $end = min($totalPages, $current + 2);
    
    if ($start > 1) {
        $html .= '<li><a href="' . e($baseUrl . '?page=1') . '">1</a></li>';
        if ($start > 2) $html .= '<li class="ellipsis">...</li>';
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $current ? ' class="active"' : '';
        $html .= '<li' . $active . '><a href="' . e($baseUrl . '?page=' . $i) . '">' . $i . '</a></li>';
    }
    
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) $html .= '<li class="ellipsis">...</li>';
        $html .= '<li><a href="' . e($baseUrl . '?page=' . $totalPages) . '">' . $totalPages . '</a></li>';
    }
    
    // Next
    if ($current < $totalPages) {
        $html .= '<li><a href="' . e($baseUrl . '?page=' . ($current + 1)) . '">&raquo;</a></li>';
    }
    
    $html .= '</ul></nav>';
    return $html;
}

/**
 * Format gold/money display
 */
function formatGold(int $amount): string
{
    return number_format($amount) . ' <span class="gold-icon">G</span>';
}

/**
 * Format credits display
 */
function formatCredits(int $amount): string
{
    return number_format($amount) . ' <span class="credit-icon">CP</span>';
}

/**
 * Truncate text with ellipsis
 */
function truncate(string $text, int $length, string $suffix = '...'): string
{
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length - strlen($suffix)) . $suffix;
}

/**
 * Generate meta tags
 */
function metaTags(string $title, string $description = '', string $image = ''): string
{
    $siteName = SERVER_NAME;
    $fullTitle = $title ? "{$title} | {$siteName}" : $siteName;
    $description = $description ?: "Join {$siteName} - An epic pirate MMORPG adventure awaits!";
    $image = $image ?: SITE_URL . '/assets/images/og-image.jpg';
    $url = SITE_URL . ($_SERVER['REQUEST_URI'] ?? '/');
    
    return <<<HTML
    <title>{$fullTitle}</title>
    <meta name="description" content="{$description}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{$fullTitle}">
    <meta property="og:description" content="{$description}">
    <meta property="og:image" content="{$image}">
    <meta property="og:url" content="{$url}">
    <meta property="og:site_name" content="{$siteName}">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{$fullTitle}">
    <meta name="twitter:description" content="{$description}">
    <meta name="twitter:image" content="{$image}">
HTML;
}
