<?php
/**
 * PKO Website Database Connection Manager
 * 
 * Provides secure database connections using PDO with SQL Server
 * All queries use parameterized statements to prevent SQL injection
 */

declare(strict_types=1);

class Database
{
    private static ?PDO $accountDb = null;
    private static ?PDO $gameDb = null;
    private static ?PDO $webDb = null;
    
    /**
     * Get connection options for PDO
     */
    private static function getConnectionOptions(): array
    {
        return [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_UTF8,
        ];
    }
    
    /**
     * Create DSN string for SQL Server
     */
    private static function createDsn(string $host, string $database): string
    {
        return "sqlsrv:Server={$host};Database={$database};TrustServerCertificate=1";
    }
    
    /**
     * Connect to AccountServer database
     */
    public static function getAccountDb(): PDO
    {
        if (self::$accountDb === null) {
            try {
                self::$accountDb = new PDO(
                    self::createDsn(DB_ACCOUNT_HOST, DB_ACCOUNT_NAME),
                    DB_ACCOUNT_USER,
                    DB_ACCOUNT_PASS,
                    self::getConnectionOptions()
                );
            } catch (PDOException $e) {
                error_log("AccountServer DB connection failed: " . $e->getMessage());
                throw new Exception("Database connection failed. Please try again later.");
            }
        }
        return self::$accountDb;
    }
    
    /**
     * Connect to GameDB database
     */
    public static function getGameDb(): PDO
    {
        if (self::$gameDb === null) {
            try {
                self::$gameDb = new PDO(
                    self::createDsn(DB_GAME_HOST, DB_GAME_NAME),
                    DB_GAME_USER,
                    DB_GAME_PASS,
                    self::getConnectionOptions()
                );
            } catch (PDOException $e) {
                error_log("GameDB connection failed: " . $e->getMessage());
                throw new Exception("Database connection failed. Please try again later.");
            }
        }
        return self::$gameDb;
    }
    
    /**
     * Connect to WebsiteDB database
     */
    public static function getWebDb(): PDO
    {
        if (self::$webDb === null) {
            try {
                self::$webDb = new PDO(
                    self::createDsn(DB_WEB_HOST, DB_WEB_NAME),
                    DB_WEB_USER,
                    DB_WEB_PASS,
                    self::getConnectionOptions()
                );
            } catch (PDOException $e) {
                error_log("WebsiteDB connection failed: " . $e->getMessage());
                throw new Exception("Database connection failed. Please try again later.");
            }
        }
        return self::$webDb;
    }
    
    /**
     * Close all database connections
     */
    public static function closeAll(): void
    {
        self::$accountDb = null;
        self::$gameDb = null;
        self::$webDb = null;
    }
}

/**
 * Account Model - Handles account-related database operations
 */
class AccountModel
{
    /**
     * Find account by username (using parameterized query)
     */
    public static function findByUsername(string $username): ?array
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("
            SELECT id, name, password, email, login_status, ban, 
                   last_login_time, last_login_ip, total_live_time,
                   enable_login_time
            FROM account_login 
            WHERE name = ?
        ");
        $stmt->execute([$username]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Find account by ID
     */
    public static function findById(int $id): ?array
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("
            SELECT id, name, email, login_status, ban, 
                   last_login_time, last_login_ip, total_live_time
            FROM account_login 
            WHERE id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Check if username exists
     */
    public static function usernameExists(string $username): bool
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("SELECT 1 FROM account_login WHERE name = ?");
        $stmt->execute([$username]);
        return $stmt->fetch() !== false;
    }
    
    /**
     * Check if email exists
     */
    public static function emailExists(string $email): bool
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("SELECT 1 FROM account_login WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch() !== false;
    }
    
    /**
     * Create new account using stored procedure
     */
    public static function create(string $username, string $password, string $email): ?int
    {
        $db = Database::getAccountDb();
        
        // Hash password with bcrypt
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);
        
        try {
            $stmt = $db->prepare("{CALL dbo.InsertNewUser(?, ?, ?)}");
            $stmt->execute([$username, $hashedPassword, $email]);
            $result = $stmt->fetch();
            return $result ? (int)$result['NewAccountId'] : null;
        } catch (PDOException $e) {
            error_log("Account creation failed: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Verify password using bcrypt
     */
    public static function verifyPassword(array $account, string $password): bool
    {
        return password_verify($password, $account['password']);
    }
    
    /**
     * Verify password by username (fetches password from DB)
     */
    public static function verifyPasswordByUsername(string $username, string $password): bool
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("SELECT password FROM account_login WHERE name = ?");
        $stmt->execute([$username]);
        $result = $stmt->fetch();
        
        if (!$result || empty($result['password'])) {
            return false;
        }
        
        return password_verify($password, $result['password']);
    }
    
    /**
     * Update last login info
     */
    public static function updateLoginInfo(int $accountId, string $ip): void
    {
        $db = Database::getAccountDb();
        try {
            $stmt = $db->prepare("{CALL dbo.InsertUserLogin(?, ?, ?)}");
            $stmt->execute([(string)$accountId, '', $ip]);
        } catch (PDOException $e) {
            error_log("Login info update failed: " . $e->getMessage());
        }
    }
    
    /**
     * Update password
     */
    public static function updatePassword(string $username, string $newPassword): bool
    {
        $db = Database::getAccountDb();
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);
        
        try {
            $stmt = $db->prepare("{CALL dbo.UpdateUserPassword(?, ?)}");
            $stmt->execute([$username, $hashedPassword]);
            return true;
        } catch (PDOException $e) {
            error_log("Password update failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get account details (VIP status, credit, etc.)
     */
    public static function getDetails(int $accountId): ?array
    {
        $db = Database::getAccountDb();
        $stmt = $db->prepare("
            SELECT acc_id, vipstatus, credit, create_time
            FROM account_details 
            WHERE acc_id = ?
        ");
        $stmt->execute([$accountId]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Get total online players
     */
    public static function getOnlineCount(): int
    {
        $db = Database::getAccountDb();
        $stmt = $db->query("SELECT COUNT(*) as count FROM account_login WHERE login_status = 1");
        $result = $stmt->fetch();
        return (int)($result['count'] ?? 0);
    }
    
    /**
     * Get GM level from GameDB
     */
    public static function getGmLevel(int $accountId): int
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("SELECT gm FROM account WHERE act_id = ?");
        $stmt->execute([$accountId]);
        $result = $stmt->fetch();
        return (int)($result['gm'] ?? 0);
    }

    /**
     * Get total registered accounts
     */
    public static function getTotalAccounts(): int
    {
        $db = Database::getAccountDb();
        $stmt = $db->query("SELECT COUNT(*) as count FROM account_login");
        $result = $stmt->fetch();
        return (int)($result['count'] ?? 0);
    }
}

/**
 * Character Model - Handles character-related database operations
 */
class CharacterModel
{
    /**
     * Get characters for an account
     */
    public static function getByAccountId(int $accountId): array
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("
            SELECT cha_id, cha_name, job, degree, exp, hp, sp, 
                   [str], dex, agi, con, sta, luk, gd, map,
                   guild_id, look, credit, IMP, battle_power
            FROM character 
            WHERE act_id = ? AND delflag = 0
            ORDER BY degree DESC
        ");
        $stmt->execute([$accountId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get character by ID
     */
    public static function findById(int $chaId): ?array
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("
            SELECT cha_id, cha_name, motto, job, degree, exp, hp, sp, ap, tp, gd,
                   [str], dex, agi, con, sta, luk, map, map_x, map_y,
                   guild_id, guild_stat, look, credit, IMP, battle_power,
                   sail_lv, live_lv, act_id
            FROM character 
            WHERE cha_id = ? AND delflag = 0
        ");
        $stmt->execute([$chaId]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Get character by name
     */
    public static function findByName(string $name): ?array
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("
            SELECT cha_id, cha_name, job, degree, exp, 
                   guild_id, look, battle_power, act_id
            FROM character 
            WHERE cha_name = ? AND delflag = 0
        ");
        $stmt->execute([$name]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Get top characters by level
     */
    public static function getTopByLevel(int $limit = 10): array
    {
        $db = Database::getGameDb();
        $limit = (int)$limit; // Ensure integer
        $stmt = $db->query("
            SELECT TOP {$limit} c.cha_id, c.cha_name, c.job, c.degree, c.exp,
                   c.battle_power, c.guild_id, g.guild_name
            FROM character c
            LEFT JOIN guild g ON c.guild_id = g.guild_id
            WHERE c.delflag = 0
            ORDER BY c.degree DESC, c.exp DESC
        ");
        return $stmt->fetchAll();
    }
    
    /**
     * Get top characters by gold
     */
    public static function getTopByGold(int $limit = 10): array
    {
        $db = Database::getGameDb();
        $limit = (int)$limit; // Ensure integer
        $stmt = $db->query("
            SELECT TOP {$limit} c.cha_id, c.cha_name, c.job, c.degree, c.gd,
                   c.guild_id, g.guild_name
            FROM character c
            LEFT JOIN guild g ON c.guild_id = g.guild_id
            WHERE c.delflag = 0
            ORDER BY c.gd DESC
        ");
        return $stmt->fetchAll();
    }
    
    /**
     * Get total characters
     */
    public static function getTotalCharacters(): int
    {
        $db = Database::getGameDb();
        $stmt = $db->query("SELECT COUNT(*) as count FROM character WHERE delflag = 0");
        $result = $stmt->fetch();
        return (int)($result['count'] ?? 0);
    }
    
    /**
     * Search characters by name
     */
    public static function search(string $query, int $limit = 20): array
    {
        $db = Database::getGameDb();
        $limit = (int)$limit; // Ensure integer
        $stmt = $db->prepare("
            SELECT TOP {$limit} cha_id, cha_name, job, degree, guild_id
            FROM character 
            WHERE cha_name LIKE ? AND delflag = 0
            ORDER BY degree DESC
        ");
        $stmt->execute(["%{$query}%"]);
        return $stmt->fetchAll();
    }
}

/**
 * Guild Model - Handles guild-related database operations
 */
class GuildModel
{
    /**
     * Get guild by ID
     */
    public static function findById(int $guildId): ?array
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("
            SELECT g.guild_id, g.guild_name, g.motto, g.leader_id, g.exp, g.level,
                   g.member_total, c.cha_name as leader_name
            FROM guild g
            LEFT JOIN character c ON g.leader_id = c.cha_id
            WHERE g.guild_id = ?
        ");
        $stmt->execute([$guildId]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Get guild members
     */
    public static function getMembers(int $guildId): array
    {
        $db = Database::getGameDb();
        $stmt = $db->prepare("
            SELECT cha_id, cha_name, job, degree, guild_stat
            FROM character 
            WHERE guild_id = ? AND delflag = 0
            ORDER BY guild_stat DESC, degree DESC
        ");
        $stmt->execute([$guildId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get top guilds by member count
     */
    public static function getTopByMembers(int $limit = 10): array
    {
        $db = Database::getGameDb();
        $limit = (int)$limit; // Ensure integer
        $stmt = $db->query("
            SELECT TOP {$limit} g.guild_id, g.guild_name, g.motto, g.level, g.exp,
                   g.member_total, c.cha_name as leader_name
            FROM guild g
            LEFT JOIN character c ON g.leader_id = c.cha_id
            WHERE g.guild_name NOT LIKE 'Pirate Guild %'
            ORDER BY g.member_total DESC, g.level DESC
        ");
        return $stmt->fetchAll();
    }
    
    /**
     * Get total guilds (excluding placeholders)
     */
    public static function getTotalGuilds(): int
    {
        $db = Database::getGameDb();
        $stmt = $db->query("SELECT COUNT(*) as count FROM guild WHERE guild_name NOT LIKE 'Pirate Guild %'");
        $result = $stmt->fetch();
        return (int)($result['count'] ?? 0);
    }
}

/**
 * Vote Model - Handles voting system
 */
class VoteModel
{
    /**
     * Get all vote sites
     */
    public static function getSites(): array
    {
        $db = Database::getWebDb();
        $stmt = $db->query("SELECT id, name, prize, link, image FROM vote");
        return $stmt->fetchAll();
    }
    
    /**
     * Check if user can vote on a specific site
     */
    public static function canVote(int $accountId, int $siteId, string $ip): bool
    {
        $db = Database::getWebDb();
        
        // Check cooldown by account
        $stmt = $db->prepare("
            SELECT TOP 1 [date] 
            FROM vote_log 
            WHERE act_id = ? AND id = ?
            ORDER BY [date] DESC
        ");
        $stmt->execute([$accountId, (string)$siteId]);
        $lastVote = $stmt->fetch();
        
        if ($lastVote) {
            $lastVoteTime = strtotime($lastVote['date']);
            $cooldownEnd = $lastVoteTime + (VOTE_COOLDOWN_HOURS * 3600);
            if (time() < $cooldownEnd) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Record a vote
     */
    public static function recordVote(int $accountId, string $username, int $siteId, string $ip): bool
    {
        $db = Database::getWebDb();
        
        try {
            $stmt = $db->prepare("
                INSERT INTO vote_log (ip, act_id, account, id, [date])
                VALUES (?, ?, ?, ?, GETDATE())
            ");
            $stmt->execute([$ip, $accountId, $username, (string)$siteId]);
            
            // Add credit to account
            $site = self::getSiteById($siteId);
            if ($site) {
                $gameDb = Database::getGameDb();
                $creditStmt = $gameDb->prepare("
                    UPDATE account 
                    SET total_votes = total_votes + 1, credit = credit + ?
                    WHERE act_id = ?
                ");
                $creditStmt->execute([$site['prize'], $accountId]);
            }
            
            return true;
        } catch (PDOException $e) {
            error_log("Vote recording failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get specific vote site
     */
    public static function getSiteById(int $siteId): ?array
    {
        $db = Database::getWebDb();
        $stmt = $db->prepare("SELECT id, name, prize, link, image FROM vote WHERE id = ?");
        $stmt->execute([$siteId]);
        $result = $stmt->fetch();
        return $result ?: null;
    }
}

/**
 * Item Shop Model - Handles in-game shop
 */
class ShopModel
{
    /**
     * Get all shop items
     */
    public static function getItems(string $category = null): array
    {
        $db = Database::getWebDb();
        
        if ($category) {
            $stmt = $db->prepare("
                SELECT TavaraListaID, TuoNimi, TavaraHinta, TavaraTeksti, 
                       Quota, Icon, MyyniTyyppi, TavaraID, MontaTavaraa, category, bought
                FROM LarryEdit 
                WHERE category = ? AND Quota > bought
                ORDER BY TavaraListaID
            ");
            $stmt->execute([$category]);
        } else {
            $stmt = $db->query("
                SELECT TavaraListaID, TuoNimi, TavaraHinta, TavaraTeksti, 
                       Quota, Icon, MyyniTyyppi, TavaraID, MontaTavaraa, category, bought
                FROM LarryEdit 
                WHERE Quota > bought
                ORDER BY category, TavaraListaID
            ");
        }
        
        return $stmt->fetchAll();
    }
    
    /**
     * Get shop categories
     */
    public static function getCategories(): array
    {
        $db = Database::getWebDb();
        $stmt = $db->query("SELECT DISTINCT TRIM(category) as category FROM LarryEdit ORDER BY category");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Purchase an item
     */
    public static function purchase(int $accountId, int $itemId, int $chaId): array
    {
        $db = Database::getWebDb();
        
        // Get item details
        $stmt = $db->prepare("
            SELECT TavaraListaID, TuoNimi, TavaraHinta, TavaraID, MontaTavaraa, 
                   Icon, Quota, bought
            FROM LarryEdit 
            WHERE TavaraListaID = ?
        ");
        $stmt->execute([$itemId]);
        $item = $stmt->fetch();
        
        if (!$item) {
            return ['success' => false, 'error' => 'Item not found'];
        }
        
        if ($item['Quota'] <= $item['bought']) {
            return ['success' => false, 'error' => 'Item out of stock'];
        }
        
        // Get account credit
        $gameDb = Database::getGameDb();
        $creditStmt = $gameDb->prepare("SELECT credit FROM account WHERE act_id = ?");
        $creditStmt->execute([$accountId]);
        $account = $creditStmt->fetch();
        
        if (!$account || $account['credit'] < $item['TavaraHinta']) {
            return ['success' => false, 'error' => 'Insufficient credits'];
        }
        
        // Get character info
        $chaStmt = $gameDb->prepare("SELECT cha_name FROM character WHERE cha_id = ? AND act_id = ?");
        $chaStmt->execute([$chaId, $accountId]);
        $character = $chaStmt->fetch();
        
        if (!$character) {
            return ['success' => false, 'error' => 'Character not found'];
        }
        
        try {
            // Start transaction
            $gameDb->beginTransaction();
            $db->beginTransaction();
            
            // Deduct credits
            $deductStmt = $gameDb->prepare("UPDATE account SET credit = credit - ? WHERE act_id = ?");
            $deductStmt->execute([$item['TavaraHinta'], $accountId]);
            
            // Update bought count
            $updateStmt = $db->prepare("UPDATE LarryEdit SET bought = bought + 1 WHERE TavaraListaID = ?");
            $updateStmt->execute([$itemId]);
            
            // Add to delivery box
            $deliveryStmt = $db->prepare("
                INSERT INTO LarryLaatikko (act_id, item_id, assigned, assigned_char, assigned_date, Icon, TuoNimi, MontaTavaraa)
                VALUES (?, ?, 0, ?, GETDATE(), ?, ?, ?)
            ");
            $deliveryStmt->execute([
                $accountId,
                (string)$item['TavaraID'],
                $character['cha_name'],
                $item['Icon'],
                $item['TuoNimi'],
                $item['MontaTavaraa']
            ]);
            
            $gameDb->commit();
            $db->commit();
            
            return ['success' => true, 'message' => 'Purchase successful! Check your in-game delivery box.'];
        } catch (PDOException $e) {
            $gameDb->rollBack();
            $db->rollBack();
            error_log("Purchase failed: " . $e->getMessage());
            return ['success' => false, 'error' => 'Transaction failed. Please try again.'];
        }
    }
}
